# Django settings for voo2do project.

import os, sys, logging

ROOT_PATH = os.path.dirname(__file__)
sys.path.append(ROOT_PATH+'/lib')


DEBUG = False
TEMPLATE_DEBUG = DEBUG

ADMINS = (
#    ('Your Name', 'your_email@domain.com'),
)

MANAGERS = ADMINS

# database settings moved to local_settings.py[.template]

# Local time zone for this installation. Choices can be found here:
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# although not all choices may be available on all operating systems.
# If running in a Windows environment this must be set to the same as your
# system time zone.
# TIME_ZONE = 'America/New_York'
#
# For Voo2do, this should be set to UTC; time zone conversions are done a
# per-user basis in the application.  Therefore, this setting primarily
# affects how timestamps are stored in the database, and the most sane way
# to do that for an international app is to use UTC.
TIME_ZONE = 'UTC'

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = True

# Absolute path to the directory that holds media.
# Example: "/home/media/media.lawrence.com/"
MEDIA_ROOT = ROOT_PATH + '/static/'

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash if there is a path component (optional in other cases).
# Examples: "http://media.lawrence.com", "http://example.com/media/"
MEDIA_URL = '/static/'

# URL prefix for admin media -- CSS, JavaScript and images. Make sure to use a
# trailing slash.
# Examples: "http://foo.com/media/", "/media/".
ADMIN_MEDIA_PREFIX = '/media/'

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.load_template_source',
    'django.template.loaders.app_directories.load_template_source',
#     'django.template.loaders.eggs.load_template_source',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
#    'debug_toolbar.middleware.DebugToolbarMiddleware',
    'splango.middleware.ExperimentsMiddleware',
    'util.middleware.ConsoleExceptionMiddleware',
    'util.middleware.XUidHeaderMiddleware',
    'util.ssl_middleware.SSLRedirect',
)

ROOT_URLCONF = 'voo2do.urls'

TEMPLATE_DIRS = (
    # Put strings here, like "/home/html/django_templates" or "C:/www/django/templates".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
    ROOT_PATH + '/templates_nf', # use nonfree templates if available
    ROOT_PATH + '/templates',
)

INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.admin',
    'django.contrib.admindocs',
    'django.contrib.humanize',
    'debug_toolbar',
    'compress',
    'django_extensions',
    'south',
    'splango',
    'account',
    'navigation',
    'todo',
    'voo2do_nf', # nonfree app, if available
    'help',
    'premium',
)

TEMPLATE_CONTEXT_PROCESSORS = (
    'django.core.context_processors.request',
    'django.core.context_processors.auth',
    'navigation.context_processors.tabs',
    'util.context_processors.important_settings',
    'util.context_processors.feature_level',
)

# req'd for debug toolbar
INTERNAL_IPS = ('127.0.0.1',)


# django.contrib.auth customizations
LOGIN_URL = "/account/login_or_register/"
LOGIN_REDIRECT_URL = "/dashboard/"
AUTH_PROFILE_MODULE = "account.profile"
AUTHENTICATION_BACKENDS = ('account.email_auth.EmailBackend',)

REMEMBER_ME_SESSION_TIMEOUT = 4*7*24*60*60 # four weeks

HOST_BASE_URL_NO_PROTOCOL = "voo2do.com"
HOST_BASE_URL = "http://"+HOST_BASE_URL_NO_PROTOCOL # no trailing slash
TASK_EMAIL_DOMAIN = HOST_BASE_URL_NO_PROTOCOL

PASSWORD_RESET_EXPIRATION_INTERVAL = 60*60*24 # 24h from now, in seconds
EMAIL_VALIDATION_EXPIRATION_INTERVAL = 60*60*24*5 # 5d from now, in seconds
API_LOGIN_INTERVAL = 60*60*24*7 # 7 days
API_MAX_LIMIT = 6000
API_DEFAULT_LIMIT = 2000
NOTIFICATION_FROM_ADDRESS = "support@voo2do.com"

NUM_COMPLETED_TASKS_IN_TASKTAG_DETAILS = 50
NUM_INCOMPLETE_TASKS_MAX = 100 # max # tasks to show in /tasks/ page so as to not cause client-side javascript overload

EMAIL_HOST="localhost"
EMAIL_PORT="25"


# django-compress settings
COMPRESS = False #SR: disabled for djangozoom # not(DEBUG)
COMPRESS_AUTO = True
COMPRESS_VERSION = True
COMPRESS_CSS = {
    'sitestyle': {
        'source_filenames': ('css/style.css', 
                             'jquery-ui/css/redmond/jquery-ui-1.7.2.custom.css',
                             'css/jquery.fg.menu.css',
                             'css/jquery.autocomplete.css'),
        'output_filename': 'css/style.r?.compressed.css',
        'extra_context': {
            'media': 'screen,projection,print',
        },
    },
    
    'pubproj_style': {
        'source_filenames': ("css/pubproj_style.css",),
        'output_filename': 'css/style.r?.compressed.css',
        'extra_context': {
            'media': 'screen,projection,print',
        },
    },
}

COMPRESS_JS = {
    "jquery": {
        "source_filenames": ("js/jquery-1.4.js",),
        "output_filename": "js/jquery.r?.compressed.js",
        },

    "basics": {
        "source_filenames": (#"js/rerror-instrumentation.js",
                             "js/jquery-1.4.js", 
                             "js/jquery.voodookit.js", 
                             "js/jquery.color.js",
                             "js/jquery.cookie.js",
                             "jquery-ui/jquery-ui-1.7.2.custom.min.js",
                             "js/util.js",
                             "js/userPrefs.js",
                             "js/contexts.js"),
        "output_filename": "js/basics.r?.compressed.js",
        },

    "tasklist": {
        "source_filenames": ("js/jquery.fg.menu.js",
                             "js/jquery.autocomplete.js",
                             "js/jquery.voodookit.customizations.js",
                             "js/taskchange.js",
                             "js/taskslist.js"),
        "output_filename": "js/tasklist.r?.compressed.js",
        },

    "tasktags": {
        "source_filenames": ("js/tasktags.js",),
        "output_filename": "js/tasktags.r?.compressed.js",
        },

    "notes": {
        "source_filenames": ("js/notes.js",),
        "output_filename": "js/notes.r?.compressed.js",
        },

    "publictasklistform": {
        "source_filenames": ("js/publictasklistform.js",),
        "output_filename": "js/publictasklistform.r?.compressed.js",
        },

    "dashbd": {
        "source_filenames": ("js/jquery.fg.menu.js",
                             "js/jquery.voodookit.customizations.js",
                             "js/taskchange.js",
                             "js/dashboard.js"),
        "output_filename": "js/dashbd.r?.compressed.js",
        
        },

    "timezone": {
        "source_filenames": ("js/timezone.js",),
        "output_filename": "js/timezone.r?.compressed.js",
        },

    "welcome": {
        "source_filenames": ("js/welcome.js",),
        "output_filename": "js/welcome.r?.compressed.js",
        },

    "timesheet": {
        "source_filenames": ("js/timesheet.js",),
        "output_filename": "js/timesheet.r?.compressed.js",
        },

}

V2_IS_BETA = False

SPLANGO_FIRST_VISIT_GOAL = "first visit"

SPREEDLY_SITE_NAME = "voo2do"
SPREEDLY_API_KEY = "1e2f2af9dbff254e0ef0673bf2198fd5b0b17597"

ENABLE_SSL_MIDDLEWARE = False#True

try:
    from local_settings import *
except ImportError:
    pass
