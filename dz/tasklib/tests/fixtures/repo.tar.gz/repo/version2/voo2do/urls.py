from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

try:
    from voo2do_nf.urls import urlpatterns
except ImportError:
    from voo2do_free.urls import urlpatterns


#from todo.urls import urlpatterns as todo_urlpatterns
#urlpatterns += todo_urlpatterns

urlpatterns += patterns('',
    (r'', include('todo.urls')),
    (r'', include('collab.urls_pub')),
    (r'^collab/', include('collab.urls')),

    (r'^admin/doc/', include('django.contrib.admindocs.urls')),
    (r'^admin/reports/', include('admin_reports.urls')),
    url(r'^admin/(.*)', admin.site.root, kwargs={"SSL":True}),

    (r'^account/', include('account.urls')),
    (r'^premium/', include('premium.urls')),
    (r'^help/', include('help.urls')),
    (r'^api/', include('api.urls')),
    (r'^split_tests/', include('splango.urls')),

    (r'^static/(?P<path>.*)$', 'django.views.static.serve', {'document_root': 'static'}),
)
